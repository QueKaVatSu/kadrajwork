import { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { 
  Home, Users, Calendar, CheckSquare, MessageCircle, 
  BarChart2, FileText, Settings, ChevronDown, ChevronRight,
  Phone, BriefcaseBusiness, Database
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useLanguage } from '@/lib/i18n/language-context';
import { 
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

type NavItemProps = {
  icon: React.ReactNode;
  labelKey: string;
  path: string;
  exact?: boolean;
  count?: number;
}

function NavItem({ icon, labelKey, path, exact = false, count }: NavItemProps) {
  const { t } = useLanguage();
  
  return (
    <NavLink
      to={path}
      end={exact}
      className={({ isActive }) => cn(
        "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium",
        "transition-all hover:bg-accent hover:text-accent-foreground",
        isActive ? "bg-accent text-accent-foreground" : "text-muted-foreground"
      )}
    >
      <span className="flex h-6 w-6 items-center justify-center">{icon}</span>
      <span className="flex-1">{t(labelKey)}</span>
      {count !== undefined && (
        <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] font-medium text-primary-foreground">
          {count > 99 ? '99+' : count}
        </span>
      )}
    </NavLink>
  );
}

type NavGroupProps = {
  labelKey: string;
  icon: React.ReactNode;
  defaultOpen?: boolean;
  children: React.ReactNode;
}

function NavGroup({ labelKey, icon, defaultOpen = false, children }: NavGroupProps) {
  const [isOpen, setIsOpen] = useState(defaultOpen);
  const { t } = useLanguage();

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen} className="w-full">
      <CollapsibleTrigger className="flex w-full items-center justify-between rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-all hover:bg-accent hover:text-accent-foreground">
        <div className="flex items-center gap-3">
          <span className="flex h-6 w-6 items-center justify-center">{icon}</span>
          <span>{t(labelKey)}</span>
        </div>
        <span className="h-4 w-4">
          {isOpen ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
        </span>
      </CollapsibleTrigger>
      <CollapsibleContent className="pl-9 pt-1 pb-2">{children}</CollapsibleContent>
    </Collapsible>
  );
}

export function Sidebar() {
  return (
    <div className="hidden md:flex flex-col w-64 border-r bg-background">
      <div className="flex h-16 items-center justify-center border-b px-4">
        <NavLink to="/" className="flex items-center justify-center">
          <img src="/assets/logo.png" alt="Kadraj Work Logo" className="h-14" />
        </NavLink>
      </div>
      <div className="flex flex-col h-[calc(100vh-64px)]">
        <nav className="flex-1 overflow-y-auto p-2">
          <div className="space-y-1">
            <NavItem icon={<Home size={18} />} labelKey="sidebar.dashboard" path="/" exact />
            
            <NavGroup labelKey="sidebar.crm" icon={<Users size={18} />} defaultOpen>
              <NavItem icon={<Users size={18} />} labelKey="sidebar.contacts" path="/crm/contacts" />
              <NavItem icon={<Database size={18} />} labelKey="sidebar.deals" path="/crm/deals" />
              <NavItem icon={<BriefcaseBusiness size={18} />} labelKey="sidebar.companies" path="/crm/companies" />
            </NavGroup>
            
            <NavGroup labelKey="sidebar.tasks" icon={<CheckSquare size={18} />}>
              <NavItem icon={<CheckSquare size={18} />} labelKey="sidebar.myTasks" path="/tasks/my" count={5} />
              <NavItem icon={<CheckSquare size={18} />} labelKey="sidebar.projects" path="/tasks/projects" />
              <NavItem icon={<CheckSquare size={18} />} labelKey="sidebar.scrum" path="/tasks/scrum" />
            </NavGroup>
            
            <NavItem icon={<Calendar size={18} />} labelKey="sidebar.calendar" path="/calendar" />
            <NavItem icon={<MessageCircle size={18} />} labelKey="sidebar.chat" path="/chat" count={3} />
            <NavItem icon={<Phone size={18} />} labelKey="sidebar.calls" path="/calls" />
            <NavItem icon={<FileText size={18} />} labelKey="sidebar.documents" path="/documents" />
            <NavItem icon={<BarChart2 size={18} />} labelKey="sidebar.reports" path="/reports" />
            <NavItem icon={<Settings size={18} />} labelKey="sidebar.settings" path="/settings" />
            <NavItem icon={<Users size={18} />} labelKey="sidebar.register" path="/register" />
          </div>
        </nav>
        <div className="sticky bottom-0 p-4 border-t bg-background">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground">
              JD
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-medium">John Doe</span>
              <span className="text-xs text-muted-foreground">Administrator</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}