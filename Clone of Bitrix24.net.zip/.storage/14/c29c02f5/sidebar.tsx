import { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { 
  Home, Users, Calendar, CheckSquare, MessageCircle, 
  BarChart2, FileText, Settings, ChevronDown, ChevronRight,
  Phone, BriefcaseBusiness, Database
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { 
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

type NavItemProps = {
  icon: React.ReactNode;
  label: string;
  path: string;
  exact?: boolean;
  count?: number;
}

function NavItem({ icon, label, path, exact = false, count }: NavItemProps) {
  return (
    <NavLink
      to={path}
      end={exact}
      className={({ isActive }) => cn(
        "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium",
        "transition-all hover:bg-accent hover:text-accent-foreground",
        isActive ? "bg-accent text-accent-foreground" : "text-muted-foreground"
      )}
    >
      <span className="flex h-6 w-6 items-center justify-center">{icon}</span>
      <span className="flex-1">{label}</span>
      {count !== undefined && (
        <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] font-medium text-primary-foreground">
          {count > 99 ? '99+' : count}
        </span>
      )}
    </NavLink>
  );
}

type NavGroupProps = {
  label: string;
  icon: React.ReactNode;
  defaultOpen?: boolean;
  children: React.ReactNode;
}

function NavGroup({ label, icon, defaultOpen = false, children }: NavGroupProps) {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen} className="w-full">
      <CollapsibleTrigger className="flex w-full items-center justify-between rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-all hover:bg-accent hover:text-accent-foreground">
        <div className="flex items-center gap-3">
          <span className="flex h-6 w-6 items-center justify-center">{icon}</span>
          <span>{label}</span>
        </div>
        <span className="h-4 w-4">
          {isOpen ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
        </span>
      </CollapsibleTrigger>
      <CollapsibleContent className="pl-9 pt-1 pb-2">{children}</CollapsibleContent>
    </Collapsible>
  );
}

export function Sidebar() {
  return (
    <div className="hidden md:flex flex-col w-64 border-r bg-background">
      <div className="flex h-14 items-center border-b px-4">
        <NavLink to="/" className="flex items-center gap-2 font-semibold">
          <BriefcaseBusiness className="h-6 w-6 text-primary" />
          <span className="text-xl font-bold text-primary">Bitrix24</span>
        </NavLink>
      </div>
      <nav className="flex-1 overflow-y-auto p-2">
        <div className="space-y-1">
          <NavItem icon={<Home size={18} />} label="Dashboard" path="/" exact />
          
          <NavGroup label="CRM" icon={<Users size={18} />} defaultOpen>
            <NavItem icon={<Users size={18} />} label="Contacts" path="/crm/contacts" />
            <NavItem icon={<Database size={18} />} label="Deals" path="/crm/deals" />
            <NavItem icon={<BriefcaseBusiness size={18} />} label="Companies" path="/crm/companies" />
          </NavGroup>
          
          <NavGroup label="Tasks & Projects" icon={<CheckSquare size={18} />}>
            <NavItem icon={<CheckSquare size={18} />} label="My Tasks" path="/tasks/my" count={5} />
            <NavItem icon={<CheckSquare size={18} />} label="Projects" path="/tasks/projects" />
            <NavItem icon={<CheckSquare size={18} />} label="Scrum" path="/tasks/scrum" />
          </NavGroup>
          
          <NavItem icon={<Calendar size={18} />} label="Calendar" path="/calendar" />
          <NavItem icon={<MessageCircle size={18} />} label="Chat" path="/chat" count={3} />
          <NavItem icon={<Phone size={18} />} label="Calls" path="/calls" />
          <NavItem icon={<FileText size={18} />} label="Documents" path="/documents" />
          <NavItem icon={<BarChart2 size={18} />} label="Reports" path="/reports" />
          <NavItem icon={<Settings size={18} />} label="Settings" path="/settings" />
        </div>
      </nav>
      <div className="mt-auto p-4 border-t">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground">
            JD
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-medium">John Doe</span>
            <span className="text-xs text-muted-foreground">Administrator</span>
          </div>
        </div>
      </div>
    </div>
  );
}