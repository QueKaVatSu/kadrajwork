import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { 
  PlusCircle, 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon,
  Clock,
  MapPin,
  Users
} from "lucide-react";
import { CalendarEvent } from "@/types";

// Mock calendar events
const mockEvents: CalendarEvent[] = [
  {
    id: "1",
    title: "Team Meeting",
    start: new Date(2023, 7, 1, 10, 0),
    end: new Date(2023, 7, 1, 11, 30),
    description: "Weekly team sync meeting",
    location: "Conference Room A",
    participants: ["1", "2", "3"],
    createdBy: "1",
  },
  {
    id: "2",
    title: "Client Presentation",
    start: new Date(2023, 7, 3, 14, 0),
    end: new Date(2023, 7, 3, 15, 0),
    description: "Presenting new designs to Acme Corp",
    location: "Meeting Room B",
    participants: ["1", "4"],
    createdBy: "1",
  },
  {
    id: "3",
    title: "Product Launch Planning",
    start: new Date(2023, 7, 5, 13, 0),
    end: new Date(2023, 7, 5, 16, 0),
    description: "Finalize plans for Q3 product launch",
    location: "Marketing Department",
    participants: ["1", "2", "5", "6"],
    createdBy: "2",
  },
  {
    id: "4",
    title: "Interview: Senior Developer",
    start: new Date(2023, 7, 10, 11, 0),
    end: new Date(2023, 7, 10, 12, 0),
    description: "Interview candidate for senior developer position",
    location: "HR Office",
    participants: ["1", "3"],
    createdBy: "3",
  },
  {
    id: "5",
    title: "Budget Review",
    start: new Date(2023, 7, 15, 9, 0),
    end: new Date(2023, 7, 15, 10, 30),
    description: "Q3 budget review meeting",
    location: "Finance Department",
    participants: ["1", "7", "8"],
    createdBy: "7",
  },
];

export default function CalendarPage() {
  const [date, setDate] = useState<Date>(new Date());
  const [view, setView] = useState<'month' | 'week' | 'day'>('month');
  
  const currentMonth = date.toLocaleDateString('default', { month: 'long' });
  const currentYear = date.getFullYear();
  
  // Navigate through months
  const previousMonth = () => {
    const newDate = new Date(date);
    newDate.setMonth(newDate.getMonth() - 1);
    setDate(newDate);
  };
  
  const nextMonth = () => {
    const newDate = new Date(date);
    newDate.setMonth(newDate.getMonth() + 1);
    setDate(newDate);
  };
  
  const goToToday = () => {
    setDate(new Date());
  };
  
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };
  
  const getFirstDayOfMonth = (year: number, month: number) => {
    return new Date(year, month, 1).getDay();
  };
  
  // Generate calendar grid
  const generateCalendarDays = () => {
    const year = date.getFullYear();
    const month = date.getMonth();
    
    const daysInMonth = getDaysInMonth(year, month);
    const firstDayOfMonth = getFirstDayOfMonth(year, month);
    
    // Previous month days needed to fill the first week
    const daysFromPrevMonth = firstDayOfMonth;
    
    // Generate array of day numbers
    const days = [];
    
    // Add previous month days
    const prevMonthDays = getDaysInMonth(year, month - 1);
    for (let i = 0; i < daysFromPrevMonth; i++) {
      days.push({
        day: prevMonthDays - daysFromPrevMonth + i + 1,
        currentMonth: false,
        date: new Date(year, month - 1, prevMonthDays - daysFromPrevMonth + i + 1)
      });
    }
    
    // Add current month days
    for (let i = 1; i <= daysInMonth; i++) {
      days.push({
        day: i,
        currentMonth: true,
        date: new Date(year, month, i)
      });
    }
    
    // Fill remaining grid slots with next month days
    const totalDays = Math.ceil((daysInMonth + firstDayOfMonth) / 7) * 7;
    const nextMonthDays = totalDays - (daysInMonth + firstDayOfMonth);
    
    for (let i = 1; i <= nextMonthDays; i++) {
      days.push({
        day: i,
        currentMonth: false,
        date: new Date(year, month + 1, i)
      });
    }
    
    return days;
  };
  
  // Get events for a specific date
  const getEventsForDate = (targetDate: Date) => {
    return mockEvents.filter(event => {
      const eventDate = new Date(event.start);
      return (
        eventDate.getDate() === targetDate.getDate() &&
        eventDate.getMonth() === targetDate.getMonth() &&
        eventDate.getFullYear() === targetDate.getFullYear()
      );
    });
  };
  
  // Format date to simple string for comparison
  const formatDateToString = (date: Date) => {
    return `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
  };
  
  // Check if date is today
  const isToday = (someDate: Date) => {
    const today = new Date();
    return formatDateToString(someDate) === formatDateToString(today);
  };
  
  const calendarDays = generateCalendarDays();
  
  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Calendar</h1>
            <p className="text-muted-foreground">Manage your schedule and events</p>
          </div>
          <div className="flex items-center gap-2">
            <Dialog>
              <DialogTrigger asChild>
                <Button>
                  <PlusCircle className="mr-2 h-4 w-4" />
                  New Event
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle>Create New Event</DialogTitle>
                  <DialogDescription>
                    Add a new event to your calendar.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid grid-cols-1 gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="title">Event Title</Label>
                    <Input id="title" placeholder="Enter event title" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="start-date">Start Date</Label>
                      <Input id="start-date" type="date" />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="start-time">Start Time</Label>
                      <Input id="start-time" type="time" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="end-date">End Date</Label>
                      <Input id="end-date" type="date" />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="end-time">End Time</Label>
                      <Input id="end-time" type="time" />
                    </div>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea id="description" placeholder="Enter event description" rows={3} />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="location">Location</Label>
                    <Input id="location" placeholder="Enter location" />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="participants">Participants</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select participants" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="john">John Doe</SelectItem>
                        <SelectItem value="sarah">Sarah Johnson</SelectItem>
                        <SelectItem value="mike">Mike Brown</SelectItem>
                        <SelectItem value="emily">Emily Davis</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline">Cancel</Button>
                  <Button>Create Event</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row justify-between gap-4 items-center">
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" onClick={previousMonth}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <div className="font-medium text-lg">
              {currentMonth} {currentYear}
            </div>
            <Button variant="outline" size="icon" onClick={nextMonth}>
              <ChevronRight className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={goToToday}>
              Today
            </Button>
          </div>
          <div className="flex items-center gap-2">
            <Select value={view} onValueChange={(val: 'month' | 'week' | 'day') => setView(val)}>
              <SelectTrigger className="w-[120px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="month">Month View</SelectItem>
                <SelectItem value="week">Week View</SelectItem>
                <SelectItem value="day">Day View</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="border rounded-lg bg-background shadow-sm">
          {view === 'month' && (
            <div className="grid grid-cols-7 text-sm">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
                <div key={day} className="py-2 text-center font-medium border-b">
                  {day}
                </div>
              ))}
              
              {calendarDays.map((day, i) => {
                const dayEvents = getEventsForDate(day.date);
                return (
                  <div 
                    key={i} 
                    className={`min-h-[120px] p-1 border-b border-r ${
                      !day.currentMonth ? 'bg-muted/50 text-muted-foreground' : ''
                    } ${isToday(day.date) ? 'bg-primary/10' : ''}`}
                  >
                    <div className="flex justify-between items-start">
                      <span className={`text-sm p-1 rounded-full w-7 h-7 flex items-center justify-center ${
                        isToday(day.date) ? 'bg-primary text-primary-foreground' : ''
                      }`}>
                        {day.day}
                      </span>
                    </div>
                    <div className="space-y-1 mt-1 max-h-[90px] overflow-y-auto">
                      {dayEvents.slice(0, 3).map((event) => (
                        <div 
                          key={event.id}
                          className="text-xs bg-primary/20 p-1 rounded truncate cursor-pointer hover:bg-primary/30"
                        >
                          <div className="font-medium">{formatTime(event.start)} {event.title}</div>
                        </div>
                      ))}
                      {dayEvents.length > 3 && (
                        <div className="text-xs text-muted-foreground p-1">
                          +{dayEvents.length - 3} more
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
          
          {view === 'week' && (
            <div className="p-4 flex justify-center items-center h-[500px] border-dashed border">
              <div className="text-muted-foreground text-center">
                <CalendarIcon className="mx-auto h-10 w-10 mb-2" />
                <h3 className="text-lg font-medium">Week View Coming Soon</h3>
                <p className="max-w-sm mt-1">
                  The week view is under development and will be available soon.
                </p>
              </div>
            </div>
          )}
          
          {view === 'day' && (
            <div className="p-4 flex justify-center items-center h-[500px] border-dashed border">
              <div className="text-muted-foreground text-center">
                <CalendarIcon className="mx-auto h-10 w-10 mb-2" />
                <h3 className="text-lg font-medium">Day View Coming Soon</h3>
                <p className="max-w-sm mt-1">
                  The day view is under development and will be available soon.
                </p>
              </div>
            </div>
          )}
        </div>
        
        <div>
          <h2 className="text-lg font-semibold mb-4">Upcoming Events</h2>
          <div className="space-y-3">
            {mockEvents.slice(0, 4).map((event) => (
              <div key={event.id} className="flex p-3 border rounded-lg hover:bg-accent">
                <div className="w-14 h-14 rounded-lg bg-primary/10 flex flex-col items-center justify-center mr-4 text-primary">
                  <span className="text-sm font-bold">{event.start.getDate()}</span>
                  <span className="text-xs">{event.start.toLocaleDateString(undefined, { month: 'short' })}</span>
                </div>
                <div className="flex-1">
                  <h3 className="font-medium text-sm">{event.title}</h3>
                  <div className="flex flex-wrap gap-x-4 gap-y-1 mt-1 text-xs text-muted-foreground">
                    <div className="flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      {formatTime(event.start)} - {formatTime(event.end)}
                    </div>
                    {event.location && (
                      <div className="flex items-center">
                        <MapPin className="h-3 w-3 mr-1" />
                        {event.location}
                      </div>
                    )}
                    <div className="flex items-center">
                      <Users className="h-3 w-3 mr-1" />
                      {event.participants?.length || 0} participants
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </MainLayout>
  );
}