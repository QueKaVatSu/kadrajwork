import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { MainLayout } from "@/components/layout/main-layout";
import { Activity, TrendingUp, User, Clock, CheckCircle, AlertTriangle, BarChart3 } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function Dashboard() {
  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-sm">
              Last updated: 2 minutes ago
            </Badge>
          </div>
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[
            { title: "Total Customers", value: "1,482", icon: User, change: "+12%", color: "text-blue-500" },
            { title: "Active Deals", value: "38", icon: TrendingUp, change: "+4%", color: "text-green-500" },
            { title: "Tasks Due Today", value: "12", icon: Clock, change: "-2", color: "text-orange-500" },
            { title: "Total Revenue", value: "$42,389", icon: BarChart3, change: "+8%", color: "text-purple-500" },
          ].map((stat, i) => (
            <Card key={i}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                <stat.icon className={`h-4 w-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <p className={`text-xs ${stat.change.startsWith('+') ? 'text-green-500' : 'text-red-500'}`}>
                  {stat.change} from last month
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
          {/* Activity Chart */}
          <Card className="lg:col-span-4">
            <CardHeader>
              <CardTitle>Activity Overview</CardTitle>
              <CardDescription>Your activity summary for the past 30 days</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[250px] flex items-center justify-center text-muted-foreground">
                Chart would be rendered here in a real application
              </div>
            </CardContent>
          </Card>

          {/* Tasks Overview */}
          <Card className="lg:col-span-3">
            <CardHeader>
              <CardTitle>Tasks Overview</CardTitle>
              <CardDescription>Your current task progress</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm font-medium">Completed</span>
                  </div>
                  <span className="text-sm">18/32</span>
                </div>
                <Progress value={56} className="h-2" />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-blue-500" />
                    <span className="text-sm font-medium">In Progress</span>
                  </div>
                  <span className="text-sm">10/32</span>
                </div>
                <Progress value={31} className="h-2" />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-red-500" />
                    <span className="text-sm font-medium">Overdue</span>
                  </div>
                  <span className="text-sm">4/32</span>
                </div>
                <Progress value={13} className="h-2" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          {/* Recent Activities */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Recent Activities</CardTitle>
              <CardDescription>Latest activities across your workspace</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { icon: User, color: "bg-blue-100 text-blue-700", text: "John created a new contact", time: "5 min ago" },
                  { icon: TrendingUp, color: "bg-green-100 text-green-700", text: "New deal worth $12,500 added", time: "2 hours ago" },
                  { icon: CheckCircle, color: "bg-purple-100 text-purple-700", text: "Website redesign project completed", time: "Yesterday" },
                  { icon: Activity, color: "bg-amber-100 text-amber-700", text: "Sales report for Q2 generated", time: "2 days ago" },
                ].map((activity, i) => (
                  <div key={i} className="flex items-start gap-4">
                    <div className={`rounded-full p-2 ${activity.color}`}>
                      <activity.icon className="h-4 w-4" />
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium">{activity.text}</p>
                      <p className="text-xs text-muted-foreground">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Deals */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Recent Deals</CardTitle>
              <CardDescription>Latest deals in your pipeline</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Client</TableHead>
                    <TableHead>Value</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {[
                    { client: "Acme Inc", value: "$12,500", status: "Negotiation" },
                    { client: "Globex Corp", value: "$8,750", status: "Qualified" },
                    { client: "Stark Industries", value: "$24,000", status: "Proposal" },
                    { client: "Wayne Enterprises", value: "$16,300", status: "Closed Won" },
                  ].map((deal, i) => (
                    <TableRow key={i}>
                      <TableCell className="font-medium">{deal.client}</TableCell>
                      <TableCell>{deal.value}</TableCell>
                      <TableCell>
                        <Badge variant={deal.status === "Closed Won" ? "success" : "outline"}>
                          {deal.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
}