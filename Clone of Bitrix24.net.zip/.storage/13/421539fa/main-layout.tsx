import { ReactNode } from 'react';
import { Sidebar } from './sidebar';
import { TopHeader } from './top-header';
import { cn } from '@/lib/utils';

interface MainLayoutProps {
  children: ReactNode;
  className?: string;
}

export function MainLayout({ children, className }: MainLayoutProps) {
  return (
    <div className="min-h-screen flex flex-col">
      <TopHeader />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <main className={cn("flex-1 overflow-y-auto p-4 md:p-6", className)}>
          {children}
        </main>
      </div>
    </div>
  );
}