import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { LanguageProvider } from './lib/i18n/language-context';
import NotFound from './pages/NotFound';

// Pages
import Dashboard from './pages/dashboard';
import ContactsPage from './pages/crm/contacts';
import TasksPage from './pages/tasks/my';
import CalendarPage from './pages/calendar';
import ChatPage from './pages/chat';

// Import additional pages when they're created
// import DealsPage from './pages/crm/deals';
// import CompaniesPage from './pages/crm/companies';
// import ProjectsPage from './pages/tasks/projects';

const queryClient = new QueryClient();

const App = () => (
  <LanguageProvider>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <BrowserRouter>
          <Routes>
            {/* Main pages */}
            <Route path="/" element={<Dashboard />} />
            
            {/* CRM routes */}
            <Route path="/crm/contacts" element={<ContactsPage />} />
            <Route path="/crm/deals" element={<Dashboard />} /> {/* Placeholder */}
            <Route path="/crm/companies" element={<Dashboard />} /> {/* Placeholder */}
            
            {/* Tasks routes */}
            <Route path="/tasks/my" element={<TasksPage />} />
            <Route path="/tasks/projects" element={<Dashboard />} /> {/* Placeholder */}
            <Route path="/tasks/scrum" element={<Dashboard />} /> {/* Placeholder */}
            
            {/* Calendar */}
            <Route path="/calendar" element={<CalendarPage />} />
            
            {/* Other routes */}
            <Route path="/chat" element={<ChatPage />} />
            <Route path="/calls" element={<Dashboard />} /> {/* Placeholder */}
            <Route path="/documents" element={<Dashboard />} /> {/* Placeholder */}
            <Route path="/reports" element={<Dashboard />} /> {/* Placeholder */}
            <Route path="/settings" element={<Dashboard />} /> {/* Placeholder */}
            
            {/* Not found / fallback routes */}
            <Route path="/404" element={<NotFound />} />
            <Route path="*" element={<Navigate to="/404" />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  </LanguageProvider>
);

export default App;
