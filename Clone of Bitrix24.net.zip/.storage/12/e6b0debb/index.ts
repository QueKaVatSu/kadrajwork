// Type definitions for the application

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  role: 'admin' | 'manager' | 'employee';
  department?: string;
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  status: 'new' | 'in-progress' | 'completed' | 'deferred';
  priority: 'low' | 'normal' | 'high' | 'urgent';
  dueDate?: Date;
  createdAt: Date;
  assignedTo?: string[];
  createdBy: string;
  tags?: string[];
}

export interface CRMContact {
  id: string;
  name: string;
  company?: string;
  email?: string;
  phone?: string;
  status: 'new' | 'in-progress' | 'converted' | 'closed';
  source?: string;
  createdAt: Date;
  lastActivity?: Date;
  assignedTo?: string;
  notes?: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  start: Date;
  end: Date;
  allDay?: boolean;
  description?: string;
  location?: string;
  participants?: string[];
  createdBy: string;
}

export interface ActivityLog {
  id: string;
  userId: string;
  action: string;
  target: string;
  targetId: string;
  timestamp: Date;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  read: boolean;
  createdAt: Date;
  type: 'info' | 'warning' | 'success' | 'error';
  link?: string;
}

export interface Message {
  id: string;
  senderId: string;
  recipientId: string | null; // null for group messages
  groupId?: string;
  content: string;
  timestamp: Date;
  read: boolean;
  attachments?: string[];
}

export interface NavItem {
  title: string;
  href: string;
  icon?: React.ReactNode;
  items?: NavItem[];
}