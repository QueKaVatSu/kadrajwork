import { useState } from "react";
import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  PlusCircle, 
  Search, 
  Filter, 
  SortAsc, 
  MoreHorizontal, 
  Calendar,
  CheckCircle2,
  Clock,
  AlertCircle,
  XCircle,
  User
} from "lucide-react";
import { Task } from "@/types";

// Mock tasks data
const mockTasks: Task[] = [
  {
    id: "1",
    title: "Update company website with new content",
    description: "Add new testimonials and update the about us page",
    status: "in-progress",
    priority: "high",
    dueDate: new Date("2023-08-05"),
    createdAt: new Date("2023-07-30"),
    assignedTo: ["1"],
    createdBy: "2",
    tags: ["Website", "Marketing"],
  },
  {
    id: "2",
    title: "Prepare Q3 financial report",
    description: "Compile all Q3 financial data and create presentation for board meeting",
    status: "new",
    priority: "urgent",
    dueDate: new Date("2023-08-15"),
    createdAt: new Date("2023-07-29"),
    assignedTo: ["1", "3"],
    createdBy: "2",
    tags: ["Finance", "Quarterly Report"],
  },
  {
    id: "3",
    title: "Review and approve new marketing materials",
    description: "Check new brochure designs and social media assets",
    status: "completed",
    priority: "normal",
    dueDate: new Date("2023-07-28"),
    createdAt: new Date("2023-07-25"),
    assignedTo: ["1"],
    createdBy: "3",
    tags: ["Marketing", "Design"],
  },
  {
    id: "4",
    title: "Follow up with potential clients from trade show",
    description: "Send emails to all leads collected during the recent industry exhibition",
    status: "deferred",
    priority: "low",
    dueDate: new Date("2023-08-10"),
    createdAt: new Date("2023-07-27"),
    assignedTo: ["1"],
    createdBy: "2",
    tags: ["Sales", "Leads"],
  },
  {
    id: "5",
    title: "Implement new CRM feature requests",
    description: "Add custom fields and improve search functionality",
    status: "in-progress",
    priority: "high",
    dueDate: new Date("2023-08-07"),
    createdAt: new Date("2023-07-26"),
    assignedTo: ["1"],
    createdBy: "3",
    tags: ["Development", "CRM"],
  },
  {
    id: "6",
    title: "Prepare onboarding materials for new hire",
    description: "Create welcome packet and training schedule for new marketing coordinator",
    status: "new",
    priority: "normal",
    dueDate: new Date("2023-08-02"),
    createdAt: new Date("2023-07-31"),
    assignedTo: ["1", "2"],
    createdBy: "3",
    tags: ["HR", "Onboarding"],
  },
];

export default function TasksPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("all");
  
  // Filter tasks based on search query and active tab
  const filteredTasks = mockTasks.filter(task => {
    const matchesSearch = 
      task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.tags?.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    if (activeTab === "all") return matchesSearch;
    if (activeTab === "overdue") {
      return matchesSearch && 
        task.status !== "completed" && 
        task.dueDate && 
        task.dueDate < new Date();
    }
    return matchesSearch && task.status === activeTab;
  });
  
  const getStatusIcon = (status: string) => {
    switch(status) {
      case 'new':
        return <Clock className="h-5 w-5 text-blue-500" />;
      case 'in-progress':
        return <AlertCircle className="h-5 w-5 text-amber-500" />;
      case 'completed':
        return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case 'deferred':
        return <XCircle className="h-5 w-5 text-gray-500" />;
      default:
        return <Clock className="h-5 w-5 text-blue-500" />;
    }
  };
  
  const getPriorityBadge = (priority: string) => {
    switch(priority) {
      case 'low':
        return <Badge variant="outline">Low</Badge>;
      case 'normal':
        return <Badge variant="secondary">Normal</Badge>;
      case 'high':
        return <Badge variant="warning">High</Badge>;
      case 'urgent':
        return <Badge variant="destructive">Urgent</Badge>;
      default:
        return <Badge variant="outline">{priority}</Badge>;
    }
  };
  
  const formatDate = (date: Date | undefined) => {
    if (!date) return "No date";
    
    const today = new Date();
    const tomorrow = new Date();
    tomorrow.setDate(today.getDate() + 1);
    
    if (date.toDateString() === today.toDateString()) {
      return "Today";
    } else if (date.toDateString() === tomorrow.toDateString()) {
      return "Tomorrow";
    } else {
      return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
    }
  };
  
  // Count tasks by status
  const taskCounts = {
    all: mockTasks.length,
    new: mockTasks.filter(t => t.status === "new").length,
    "in-progress": mockTasks.filter(t => t.status === "in-progress").length,
    completed: mockTasks.filter(t => t.status === "completed").length,
    deferred: mockTasks.filter(t => t.status === "deferred").length,
    overdue: mockTasks.filter(t => 
      t.status !== "completed" && 
      t.dueDate && 
      t.dueDate < new Date()
    ).length,
  };
  
  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">My Tasks</h1>
            <p className="text-muted-foreground">Manage and organize your tasks</p>
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <PlusCircle className="mr-2 h-4 w-4" />
                New Task
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Create New Task</DialogTitle>
                <DialogDescription>
                  Add a new task with details below.
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-1 gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="title">Title</Label>
                  <Input id="title" placeholder="Enter task title" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea id="description" placeholder="Enter task description" rows={3} />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="priority">Priority</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select priority" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="normal">Normal</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="urgent">Urgent</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="status">Status</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="new">New</SelectItem>
                        <SelectItem value="in-progress">In Progress</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="due-date">Due Date</Label>
                    <div className="flex items-center">
                      <Input id="due-date" type="date" />
                    </div>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="tags">Tags (comma separated)</Label>
                    <Input id="tags" placeholder="Marketing, Website, etc." />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline">Cancel</Button>
                <Button>Create Task</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
        
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
            <div className="flex items-center w-full sm:w-auto gap-2">
              <Search className="h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search tasks..."
                className="h-9 w-full sm:w-[300px]"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <Button variant="outline" size="sm">
                <Filter className="mr-2 h-4 w-4" />
                Filter
              </Button>
              <Button variant="outline" size="sm">
                <SortAsc className="mr-2 h-4 w-4" />
                Sort
              </Button>
              <Select defaultValue="me">
                <SelectTrigger className="h-9 w-[120px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="me">Assigned to me</SelectItem>
                  <SelectItem value="all">All tasks</SelectItem>
                  <SelectItem value="team">My team</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-3 md:grid-cols-6 h-auto mb-4">
              <TabsTrigger value="all" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                All <Badge variant="outline" className="ml-1">{taskCounts.all}</Badge>
              </TabsTrigger>
              <TabsTrigger value="new" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                New <Badge variant="outline" className="ml-1">{taskCounts.new}</Badge>
              </TabsTrigger>
              <TabsTrigger value="in-progress" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                In Progress <Badge variant="outline" className="ml-1">{taskCounts["in-progress"]}</Badge>
              </TabsTrigger>
              <TabsTrigger value="completed" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                Completed <Badge variant="outline" className="ml-1">{taskCounts.completed}</Badge>
              </TabsTrigger>
              <TabsTrigger value="deferred" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                Deferred <Badge variant="outline" className="ml-1">{taskCounts.deferred}</Badge>
              </TabsTrigger>
              <TabsTrigger value="overdue" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                Overdue <Badge variant="destructive" className="ml-1">{taskCounts.overdue}</Badge>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value={activeTab} className="space-y-4">
              {filteredTasks.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <div className="rounded-full bg-muted p-3 mb-3">
                    <CheckCircle2 className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-semibold">No tasks found</h3>
                  <p className="text-sm text-muted-foreground max-w-sm mt-1">
                    {searchQuery 
                      ? "No tasks match your search criteria. Try adjusting your search."
                      : "You don't have any tasks in this category yet."}
                  </p>
                  <Button variant="outline" className="mt-4">
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Create New Task
                  </Button>
                </div>
              ) : (
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {filteredTasks.map((task) => (
                    <Card key={task.id} className="relative">
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <div className="flex items-start gap-2">
                            {getStatusIcon(task.status)}
                            <div>
                              <CardTitle className="text-base">{task.title}</CardTitle>
                              <CardDescription className="line-clamp-2">
                                {task.description || "No description"}
                              </CardDescription>
                            </div>
                          </div>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Menu</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>Edit</DropdownMenuItem>
                              <DropdownMenuItem>Change Status</DropdownMenuItem>
                              <DropdownMenuItem>Add Comment</DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-destructive">Delete</DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="flex flex-wrap gap-2 my-3">
                          {task.tags?.map((tag, i) => (
                            <Badge key={i} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-between pt-2 border-t">
                        <div className="flex items-center text-sm text-muted-foreground">
                          <Calendar className="mr-1 h-3 w-3" />
                          <span>{formatDate(task.dueDate)}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {getPriorityBadge(task.priority)}
                          <div className="h-6 w-6 rounded-full bg-primary flex items-center justify-center text-xs text-primary-foreground">
                            <User className="h-3 w-3" />
                          </div>
                        </div>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </MainLayout>
  );
}