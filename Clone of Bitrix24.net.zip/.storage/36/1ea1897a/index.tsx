import { useState } from 'react';
import { Search, Send, User, Phone, Video, MoreVertical, Paperclip } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useLanguage } from '@/lib/i18n/language-context';
import { MainLayout } from '@/components/layout/main-layout';

interface Contact {
  id: number;
  name: string;
  avatar?: string;
  lastMessage: string;
  time: string;
  unread: number;
  online: boolean;
}

interface Message {
  id: number;
  content: string;
  time: string;
  sent: boolean;
  read: boolean;
}

export default function ChatPage() {
  const { t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [messageText, setMessageText] = useState('');
  const [selectedContact, setSelectedContact] = useState<number | null>(1);
  
  // Mock data for contacts
  const contacts: Contact[] = [
    { id: 1, name: 'John Smith', lastMessage: 'Can you send me the files?', time: '10:30', unread: 2, online: true },
    { id: 2, name: 'Sarah Johnson', lastMessage: 'Meeting at 2pm', time: '09:15', unread: 0, online: true },
    { id: 3, name: 'Mike Brown', lastMessage: 'Thanks for your help!', time: 'Yesterday', unread: 0, online: false },
    { id: 4, name: 'Emily Davis', lastMessage: 'Let me check and get back to you', time: 'Yesterday', unread: 0, online: false },
    { id: 5, name: 'Alex Wilson', lastMessage: 'The project is done', time: 'Monday', unread: 0, online: true },
  ];

  // Mock data for messages
  const messages: Record<number, Message[]> = {
    1: [
      { id: 1, content: 'Hi there! How are you?', time: '10:15', sent: false, read: true },
      { id: 2, content: 'I\'m good, thanks! Just working on the project.', time: '10:20', sent: true, read: true },
      { id: 3, content: 'Can you send me the files?', time: '10:30', sent: false, read: true },
    ],
    2: [
      { id: 1, content: 'Don\'t forget about our meeting', time: '09:10', sent: false, read: true },
      { id: 2, content: 'Sure, I\'ll be there', time: '09:12', sent: true, read: true },
      { id: 3, content: 'Meeting at 2pm', time: '09:15', sent: false, read: true },
    ],
  };

  const filteredContacts = contacts.filter(contact => 
    contact.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const selectedContactData = contacts.find(c => c.id === selectedContact);
  const selectedContactMessages = selectedContact ? messages[selectedContact] || [] : [];

  const handleSendMessage = () => {
    if (!messageText.trim() || !selectedContact) return;
    
    // In a real app, you would send this message to an API
    console.log(`Sending message to ${selectedContact}: ${messageText}`);
    
    // Clear the input field
    setMessageText('');
  };

  return (
    <MainLayout>
      <div className="h-[calc(100vh-3.5rem)] flex flex-col">
        <div className="flex-1 flex overflow-hidden">
          {/* Contacts sidebar */}
          <div className="w-80 border-r flex flex-col">
            <div className="p-4 border-b">
              <h2 className="font-semibold text-lg mb-3">{t('chat.title')}</h2>
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder={t('chat.searchContacts')}
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
            <div className="flex-1 overflow-y-auto">
              {filteredContacts.map(contact => (
                <div 
                  key={contact.id}
                  className={`flex items-center gap-3 p-3 cursor-pointer hover:bg-muted ${selectedContact === contact.id ? 'bg-muted' : ''}`}
                  onClick={() => setSelectedContact(contact.id)}
                >
                  <div className="relative">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                      {contact.avatar ? (
                        <img src={contact.avatar} alt={contact.name} className="h-10 w-10 rounded-full" />
                      ) : (
                        <User className="h-5 w-5 text-primary" />
                      )}
                    </div>
                    {contact.online && (
                      <div className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-green-500 border-2 border-background"></div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-baseline">
                      <p className="font-medium truncate">{contact.name}</p>
                      <span className="text-xs text-muted-foreground">{contact.time}</span>
                    </div>
                    <p className="text-sm text-muted-foreground truncate">{contact.lastMessage}</p>
                  </div>
                  {contact.unread > 0 && (
                    <div className="h-5 min-w-5 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center px-1.5">
                      {contact.unread}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
          
          {/* Chat area */}
          {selectedContact ? (
            <div className="flex-1 flex flex-col">
              {/* Chat header */}
              <div className="p-4 border-b flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <User className="h-5 w-5 text-primary" />
                    </div>
                    {selectedContactData?.online && (
                      <div className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-green-500 border-2 border-background"></div>
                    )}
                  </div>
                  <div>
                    <p className="font-medium">{selectedContactData?.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {selectedContactData?.online ? t('chat.online') : t('chat.offline')}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon">
                    <Phone className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Video className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <MoreVertical className="h-5 w-5" />
                  </Button>
                </div>
              </div>
              
              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
                {selectedContactMessages.map(message => (
                  <div 
                    key={message.id} 
                    className={`max-w-[70%] ${message.sent ? 'self-end' : 'self-start'}`}
                  >
                    <div 
                      className={`rounded-lg p-3 ${
                        message.sent 
                          ? 'bg-primary text-primary-foreground' 
                          : 'bg-muted'
                      }`}
                    >
                      {message.content}
                    </div>
                    <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground justify-end">
                      {message.time}
                      {message.sent && (
                        <span>✓{message.read ? '✓' : ''}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Message input */}
              <div className="p-4 border-t">
                <div className="flex gap-2">
                  <Button variant="ghost" size="icon">
                    <Paperclip className="h-5 w-5" />
                  </Button>
                  <Textarea 
                    placeholder={t('chat.typeMessage')}
                    className="min-h-10 resize-none"
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                  />
                  <Button onClick={handleSendMessage} disabled={!messageText.trim()}>
                    <Send className="h-5 w-5 mr-1" />
                    <span>{t('chat.send')}</span>
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center text-muted-foreground">
              {t('chat.title')}
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}