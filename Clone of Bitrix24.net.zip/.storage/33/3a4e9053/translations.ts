export const translations = {
  en: {
    sidebar: {
      dashboard: "Dashboard",
      crm: "CRM",
      contacts: "Contacts",
      deals: "Deals",
      companies: "Companies",
      tasks: "Tasks",
      myTasks: "My Tasks",
      projects: "Projects",
      scrum: "Scrum",
      calendar: "Calendar",
      chat: "Chat",
      calls: "Calls",
      documents: "Documents",
      reports: "Reports",
      settings: "Settings"
    },
    header: {
      search: "Search...",
      notifications: "Notifications",
      markAllRead: "Mark all as read",
      viewAllNotifications: "View all notifications",
      profile: "Profile",
      accountSettings: "Account Settings",
      signOut: "Sign Out",
      help: "Help & Support"
    },
    chat: {
      title: "Chat",
      newMessage: "New Message",
      searchContacts: "Search contacts...",
      typeMessage: "Type a message...",
      send: "Send",
      online: "Online",
      offline: "Offline"
    },
    common: {
      loading: "Loading...",
      noResults: "No results found",
      language: "Language"
    }
  },
  tr: {
    sidebar: {
      dashboard: "Kontrol Paneli",
      crm: "MİY",
      contacts: "Kişiler",
      deals: "Teklifler",
      companies: "Şirketler",
      tasks: "Görevler",
      myTasks: "Görevlerim",
      projects: "Projeler",
      scrum: "Scrum",
      calendar: "Takvim",
      chat: "Sohbet",
      calls: "Aramalar",
      documents: "Belgeler",
      reports: "Raporlar",
      settings: "Ayarlar"
    },
    header: {
      search: "Ara...",
      notifications: "Bildirimler",
      markAllRead: "Tümünü okundu işaretle",
      viewAllNotifications: "Tüm bildirimleri görüntüle",
      profile: "Profil",
      accountSettings: "Hesap Ayarları",
      signOut: "Oturumu Kapat",
      help: "Yardım & Destek"
    },
    chat: {
      title: "Sohbet",
      newMessage: "Yeni Mesaj",
      searchContacts: "Kişileri ara...",
      typeMessage: "Bir mesaj yazın...",
      send: "Gönder",
      online: "Çevrimiçi",
      offline: "Çevrimdışı"
    },
    common: {
      loading: "Yükleniyor...",
      noResults: "Sonuç bulunamadı",
      language: "Dil"
    }
  }
};