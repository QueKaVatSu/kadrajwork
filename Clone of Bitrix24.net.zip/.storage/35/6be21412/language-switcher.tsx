import { useLanguage } from '@/lib/i18n/language-context';
import { Button } from '@/components/ui/button';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Globe } from 'lucide-react';

export function LanguageSwitcher() {
  const { language, setLanguage, t } = useLanguage();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="gap-1">
          <Globe className="h-4 w-4" />
          <span className="hidden md:inline-flex">{language === 'en' ? 'English' : 'Türkçe'}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={() => setLanguage('en')}>
          <div className="flex items-center">
            <span className={language === 'en' ? 'font-bold' : ''}>English</span>
            {language === 'en' && <span className="ml-2 text-primary">✓</span>}
          </div>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => setLanguage('tr')}>
          <div className="flex items-center">
            <span className={language === 'tr' ? 'font-bold' : ''}>Türkçe</span>
            {language === 'tr' && <span className="ml-2 text-primary">✓</span>}
          </div>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}